import React from 'react'
import ProfilePage from '../Components/Profile/profilee'

export default function ExamplePage() {
  return (
    <ProfilePage/>
  )
}
