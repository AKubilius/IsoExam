import React from 'react'
import NavBar from '../Components/NavBar/NavBar'
import Exam from '../Components/Exam/Exam'

export default function HomePage() {
  return (
    <><NavBar/>
    <Exam/>
    </>
  )
}
//<PieChart riskAddressed={83} riskAccepted={18}  />