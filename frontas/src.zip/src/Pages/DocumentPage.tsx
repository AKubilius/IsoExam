import React from 'react'
import Navbar from '../Components/NavBar/NavBar'
import Documents from '../Components/Document/Document'

export default function DocumentPage() {
  return (
   <> <Navbar/>
    <Documents/>
    </>
  )
}
